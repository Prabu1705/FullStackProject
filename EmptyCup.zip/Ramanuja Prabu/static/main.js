function invertIcon(el1){       //is a function to adjust the style of the logo to show that it's been toggled
    el1.classList.toggle("iconclick");  
}

function showDetails(el){  //toggles details button
    const image= el.querySelector("img");
    invertIcon(image);
}
function shortlistProduct(el){  //toggles and changes the subtext of shortlist button.
    const image= el.querySelector("img");   
    const txt = el.querySelector("h6");

    const product = el.closest(".Product"); 
    product.classList.toggle("sl");//sl class is toggled to know if it is shortlisted or not     

    invertIcon(image);
    txt.innerHTML = (txt.innerHTML === "Shortlist") ? "Shortlisted" : "Shortlist";
}
function hideDetails(el){
    const image= el.querySelector("img");
    invertIcon(image);
}
function reportProduct(el){
    const image= el.querySelector("img");
    invertIcon(image);
}

let filterOn=false; 

function shortlistedProducts(el){  // function is to switch between showing shortlisted products and all products
    let image =el.querySelector("img");//the following few lines toggles between two .png 's to show visual change on shortlisting filter button
    if(image.src.endsWith("static/assets/shortlisted.png")){
        image.src="static/assets/shortlisted2.png";  
    }
    else{
        image.src="static/assets/shortlisted.png";
    }

    filterOn=!filterOn;
    const products=document.querySelectorAll(".Product");
    let anyVisible=false; // to check if there is any shorlisted product at all
    products.forEach(product=>{
        if(filterOn){
            if(product.classList.contains("sl")){
                product.style.display = "grid";
                anyVisible = true;
            }else {
                product.style.display = "none";
            }
        }else
        {
            product.style.display="grid";
            anyVisible=true;
        }
    });
    // if no shortlisted products, then add the message "no shortlisted product"
    const noItemsMsg = document.getElementById("no-items-msg");
    if (filterOn && !anyVisible) {          //if shortlist is on and no shortlist product
        if (!noItemsMsg) {
            const msg = document.createElement("p");
            msg.id = "no-items-msg";
            msg.style.textAlign = "center";
            msg.style.padding = "2rem";
            msg.style.color = "#999";
            msg.innerText = "No shortlisted products.";
            msg.style.fontSize="200%";
            bodyEle.appendChild(msg);
        }
    } else {                                    //if either filter is off or if any product is shortlisted,then remove message
        if (noItemsMsg) noItemsMsg.remove();
    }
}

const bodyEle=document.getElementById("body");

//fetches data and adds each product to the body
fetch('../data.json')
    .then(res =>res.json())
    .then(data =>{
        data.forEach((ele,index) => {
            bodyEle.insertAdjacentHTML('beforeend',`<div class="Product">
                <div class="details">
                    <h2>${ele.name}</h2>
                    <img src="static/assets/${ele.rating}stars.png"/>
                    <p>${ele.description}</p>
                    <div class="projectinfo">
                        <div>
                            <h1>${ele.projects}</h1>
                            <h5>projects</h5>                            
                        </div>
                        <div>
                            <h1>${ele.years}</h1>
                            <h5>years</h5>                            
                        </div>
                        <div>
                            <h1>${ele.price}</h1>
                            <h5>price</h5>                            
                        </div>
                    </div>
                    <div>
                        <h3>${ele.contact1}</h3>
                        <h3>${ele.contact2}</h3>
                    </div>
                </div>
                <div class="sidebar">
                    <div onclick="showDetails(this)">                
                        <img src="static/assets/details.png" />
                        <h6>Details</h6>
                    </div>
                    <div onclick="hideDetails(this)">         
                        <img src="static/assets/hide.png" />
                        <h6>Hide</h6>
                    </div>
                    <div onclick="shortlistProduct(this)">        
                        <img src="static/assets/shortlist.png"/>
                        <h6>Shortlist</h6>
                    </div>
                    <div onclick="reportProduct(this)">        
                        <img src="static/assets/report.png" />
                        <h6>Report</h6>
                    </div>

                </div>
                

            </div>`)
        });
    })


/*this code performs :
-when scrolled down, the navigation bar and title is hidden smoothly
-when scrolled up, the navigation bar and title is shown
*/
let lastScrollY=window.scrollY;
const header=document.getElementById("header");
window.addEventListener("scroll",()=>{
    if(window.scrollY<lastScrollY){
        header.classList.remove("hide");
    } 
    else{
        header.classList.add("hide");
    }
    lastScrollY=window.scrollY;
});
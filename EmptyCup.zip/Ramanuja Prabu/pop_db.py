import json
from app import db, Designer, app

with app.app_context():
    # Load data from JSON
    with open('data.json', 'r') as f:
        data = json.load(f)

    # Insert data into the database
    for item in data:
        designer = Designer(
            name=item['name'],
            rating=float(item['rating']),
            description=item['description'],
            projects=int(item['projects']),
            years=int(item['years']),
            price=item['price'],
            contact1=item['contact1'],
            contact2=item['contact2']
        )
        db.session.add(designer)

    db.session.commit()
    print("Data inserted successfully.")

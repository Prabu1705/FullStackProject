from flask import Flask,render_template,url_for,jsonify
import json
import os
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, instance_relative_config=True)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(app.instance_path, 'database.db')

db = SQLAlchemy(app)

class Designer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    rating = db.Column(db.Float)
    description = db.Column(db.Text)
    projects = db.Column(db.Integer)
    years = db.Column(db.Integer)
    price = db.Column(db.String(10))
    contact1 = db.Column(db.String(20))
    contact2 = db.Column(db.String(20))

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/data.json')
def data():
    designer = Designer.query.all()
    return jsonify([
        {
            "name":d.name,
            "rating":f"{d.rating:.1f}",
            "description": d.description,
            "projects": d.projects,
            "years": d.years,
            "price": d.price,
            "contact1": d.contact1,
            "contact2": d.contact2
        }
        for d in designer
    ])


@app.cli.command("init-db")
def init_db():
    db.create_all()
    print("initialized the db.")


if __name__=="__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
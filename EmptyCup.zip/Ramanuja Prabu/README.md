# EmptyCup — Flask Web App

**EmptyCup** is a mobile-first web application built using Flask (Python), HTML/CSS/JavaScript, and Docker. It presents a curated list of design studios with ratings, descriptions, and contact details. This project demonstrates front-end and back-end integration, database handling, and containerized deployment for evaluation purposes.

## Project Structure

```
your_project/
├── __pycache__/               # Bytecode cache
├── env/                       # Python virtual environment
├── instance/
│   └── database.db            # SQLite database
├── templates/
│   └── index.html             # HTML layout template
├── static/
│   ├── main.js                # Frontend script (fetching and rendering)
│   ├── main.css               # Styling for the interface
│   └── assets/                # Icons and images
├── app.py                     # Flask application
├── data.json                  # Raw dataset for initial population
├── dockerfile                 # Docker configuration file
├── pop_db.py                  # Script to populate the database
```

## Running the Application Locally (127.0.0.1)

This application is configured to run and be tested on `127.0.0.1`.

### Option 1: Run using Python

1. (Optional) Create a virtual environment:

   ```bash
   python -m venv env
   env\Scripts\activate   # On Windows
   ```

2. Install dependencies:

   ```bash
   pip install flask flask_sqlalchemy
   ```

3. Start the application:

   ```bash
   python app.py
   ```

4. Open a browser and navigate to:

   ```text
   http://127.0.0.1:5000
   ```

### Option 2: Run using Docker

1. Build the Docker image:

   ```bash
   docker build -t emptycup-app .
   ```

2. Run the Docker container:

   ```bash
   docker run -p 5000:5000 emptycup-app
   ```

3. Open in browser:

   ```text
   http://127.0.0.1:5000
   ```

## Database Setup

To populate the database with data from `data.json`, run the following:

```bash
python pop_db.py
```

This will insert the records into `instance/database.db` using SQLAlchemy.

## Features

- Mobile-first responsive UI(web page + styling + working shortlisting button)
- Data rendering via JavaScript fetch requests
- SQLite database integration with SQLAlchemy(backend integeration)
- Dockerized for consistent local deployment(local deployment)
